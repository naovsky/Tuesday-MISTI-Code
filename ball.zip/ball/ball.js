var ball;
ball = create();

